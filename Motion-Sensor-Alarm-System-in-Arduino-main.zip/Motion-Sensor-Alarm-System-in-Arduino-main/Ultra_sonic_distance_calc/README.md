This file is to check the distance of your motion sensor.

Import this code into a seperate arduino file, connect your device, and run it.

Then start going further and further back until it no longer reads the motion.
